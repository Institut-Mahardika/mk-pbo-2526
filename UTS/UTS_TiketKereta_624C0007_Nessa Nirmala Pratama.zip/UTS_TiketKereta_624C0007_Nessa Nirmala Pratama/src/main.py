from domain.tiket_ekonomi import TiketEkonomi
from domain.tiket_bisnis import TiketBisnis
from domain.pelanggan import Pelanggan

def menu():
    daftar_tiket = []
    pembelian = []

    while True:
        print("\n=== SISTEM TIKET KERETA API ===")
        print("[1] Pesan Tiket")
        print("[2] Lihat Daftar Tiket")
        print("[3] Lihat Ringkasan Pembelian")
        print("[4] Keluar")

        pilih = input("Pilih menu: ")

        if pilih == "1":
            nama = input("Nama Penumpang: ")
            usia = int(input("Usia: "))
            status = input("Status (pelajar/dewasa/lansia): ")
            pelanggan = Pelanggan(nama, usia, status)

            tujuan = input("Tujuan: ")
            tanggal = input("Tanggal Keberangkatan: ")
            jumlah = int(input("Jumlah Tiket: "))

            print("Kelas Kereta:")
            print("1. Ekonomi")
            print("2. Bisnis")
            kelas = input("Pilih kelas [1/2]: ")

            if kelas == "1":
                tiket = TiketEkonomi(nama, tujuan, tanggal, jumlah, usia)
            elif kelas == "2":
                tiket = TiketBisnis(nama, tujuan, tanggal, jumlah, usia)
            else:
                print("Kelas tidak valid!")
                continue

            # Tiket pulang-pergi
            pp = input("Pulang-pergi? (y/n): ").lower()
            total = tiket.hitung_total()
            if pp == "y":
                total *= 2

            # Diskon berdasarkan usia/pelajar
            diskon = pelanggan.hitung_diskon()
            if diskon > 0:
                total *= (1 - diskon)
                print(f"Diskon {int(diskon*100)}% diterapkan!")

            pembelian.append({
                "nama": nama,
                "tujuan": tujuan,
                "kelas": kelas,
                "total": total
            })
            daftar_tiket.append(tiket)
            print(f"Total Harga: Rp {total:,.0f}")
            print(f"Terima kasih telah membeli tiket, {nama}!")

        elif pilih == "2":
            print("\n=== DAFTAR TIKET ===")
            for tiket in daftar_tiket:
                print(tiket.deskripsi())
            if not daftar_tiket:
                print("Belum ada tiket yang dibeli.")

        elif pilih == "3":
            print("\n=== RINGKASAN PEMBELIAN ===")
            total_semua = sum(item["total"] for item in pembelian)
            for data in pembelian:
                print(f"{data['nama']} - {data['tujuan']} - Rp {data['total']:,.0f}")
            print(f"\nTotal Semua Pembelian: Rp {total_semua:,.0f}")

        elif pilih == "4":
            print("Terima kasih telah menggunakan sistem tiket kereta!")
            break

        else:
            print("Pilihan tidak valid!")

if __name__ == "__main__":
    menu()
