from .tiket_kereta import TiketKereta

class TiketBisnis(TiketKereta):
    def __init__(self, nama_penumpang, tujuan, tanggal, jumlah_tiket, usia, pelajar=False, pulang_pergi=False):
        super().__init__(nama_penumpang, tujuan, tanggal, jumlah_tiket)
        self.__harga_dasar = 100000
        self.usia = usia
        self.pelajar = pelajar
        self.pulang_pergi = pulang_pergi

    def hitung_total(self):
        total = self.__harga_dasar * self.jumlah_tiket
        if self.usia < 12:
            total *= 0.5
        elif self.pelajar:
            total *= 0.85
        if self.pulang_pergi:
            total *= 2
            total *= 0.9
        return total

    def deskripsi(self):
        jenis = "Pulang-Pergi" if self.pulang_pergi else "Sekali Jalan"
        return f"[BISNIS] {self.nama_penumpang} - {self.tujuan} ({jenis}) {self.jumlah_tiket} tiket, Total: Rp{self.hitung_total():,.0f}"
