# Sistem Tiket Kereta Api (UTS Pemrograman Berorientasi Objek)

## 👤 Nama & NPM

| Keterangan | Detail |
| :--- | :--- |
| **Nama** | NAHRUL HAYAT |
| **NPM** | 624C0010 |

***

## 🚀 Deskripsi Singkat Proyek

Proyek ini adalah implementasi **Sistem Pemesanan Tiket Kereta Api** berbasis konsol interaktif yang dikembangkan menggunakan Python dengan pendekatan **Object-Oriented Programming (OOP)**.

Program ini dirancang untuk:

1.  Menyediakan menu interaktif untuk pemesanan tiket.
2.  Menggunakan abstraksi dan pewarisan untuk memodelkan berbagai kelas tiket (Ekonomi, Bisnis, Eksekutif).
3.  Menerapkan validasi dan **enkapsulasi** untuk melindungi data sensitif tiket dan penumpang.
4.  Menampilkan rincian transaksi secara lengkap.

***

## 📂 Struktur Folder dan Deskripsi File

Proyek ini menggunakan struktur multi-file untuk menonjolkan arsitektur OOP.  
UTS_TiketKereta_624C0010_NAHRUL_HAYAT/
├─ src/
│  ├─ domain/
│  │  ├─ __init__.py         # Inisialisasi package domain.
│  │  ├─ tiket_kereta.py     # Class Abstrak **TiketKereta** (definisi interface).
│  │  ├─ tiket_ekonomi.py    # Subclass dari TiketKereta (Tiket Ekonomi).
│  │  ├─ tiket_bisnis.py     # Subclass dari TiketKereta (Tiket Bisnis).
│  │  └─ pelanggan.py        # Class untuk menyimpan data Pelanggan.
│  └─ main.py               # File utama, berisi fungsi Menu Interaktif dan alur program.
├─ README.md                 # File dokumentasi proyek ini.
└─ requirements.txt          # Daftar library eksternal yang dibutuhkan (kosong jika tidak ada).

***

## 🧩 Penjelasan Penerapan 4 Pilar OOP

Empat pilar utama dari OOP diterapkan secara ketat dalam perancangan kelas-kelas tiket:

### 1. Abstraksi (Abstraction)

* **Class Terkait:** `TiketKereta` (menggunakan `abc.ABC`).
* **Penerapan:** Kelas ini bertindak sebagai *interface* dengan dua method abstrak wajib (`hitung_total()` dan `deskripsi()`). Ia menyembunyikan detail perhitungan harga spesifik per kelas, hanya mendefinisikan apa yang harus dilakukan oleh setiap tiket.

### 2. Pewarisan (Inheritance)

* **Class Terkait:** `TiketEkonomi`, `TiketBisnis`, `TiketEksekutif`.
* **Penerapan:** Ketiga kelas ini mewarisi properti dan method dasar dari kelas induk `TiketKereta`. Setiap subclass memperluas fungsionalitas dengan menambahkan atribut dan logika uniknya (misalnya, diskon atau fasilitas tambahan).

### 3. Enkapsulasi (Encapulation)

* **Class Terkait:** Semua kelas tiket (misalnya `TiketBisnis`).
* **Penerapan:** Data sensitif seperti `__harga_dasar` dan `__kursi` dilindungi menggunakan atribut *private* (dengan *double underscore*). Akses dan modifikasi diizinkan hanya melalui method **getter** dan **setter** (atau `@property`).
* **Contoh Enkapsulasi:** Setter digunakan untuk melakukan **validasi input** (misalnya, memastikan harga tidak negatif atau kursi tidak kosong) sebelum data disimpan.

### 4. Polimorfisme (Polymorphism)

* **Class Terkait:** Method `hitung_total()` dan `deskripsi()` diimplementasikan ulang (Overriding) di setiap subclass.
* **Penerapan:** Konsep polimorfisme diwujudkan saat program memanggil method yang sama pada objek dari kelas yang berbeda (misalnya, membuat `list` objek tiket). Walaupun method yang dipanggil sama, hasilnya berbeda sesuai tipe objeknya:
    ```python
    daftar_tiket = [TiketEkonomi(...), TiketBisnis(...)]
    for tiket in daftar_tiket:
        print(tiket.deskripsi()) # Output unik per kelas
    ```

***

## 💬 Contoh Input dan Output Singkat

### A. Contoh Interaksi Pembelian Tiket

**Output Ringkasan Transaksi:**

--- [3] RINGKASAN PEMBELIAN TERAKHIR ---
Nama Pembeli: azril
Kelas Dibeli: BISNIS
Jumlah Tiket: 2
TOTAL BAYAR: Rp 700,000

--- Detail Tiket ---
  - Tiket 1: KA Argo Wilis | Kursi: A11 | Harga: Rp 350,000
  - Tiket 2: KA Argo Wilis | Kursi: A12 | Harga: Rp 350,000

### B. Contoh Hasil Polimorfisme

**Output `tiket.deskripsi()`:**

--- [2] DAFTAR TIKET TERSEDIA ---
------------------------------------------
[EKONOMI] KA Progo (JOG ke JKT) > Harga/tiket: Rp 120,000 | Kursi: E1A
Harga Dasar (Enkapsulasi): 120000
------------------------------------------
[BISNIS] KA Taksaka (JKT ke JOG
) > Harga/tiket: Rp 350,000 | Fasilitas: Snack + Bantal | Kursi: B2C
Harga Dasar (Enkapsulasi): 300000

***

## ▶️ Cara Menjalankan Program

Pastikan Anda berada di direktori utama proyek (`UTS_TiketKereta_624C0010_NAHRUL_HAYAT/`).

Jalankan program utama (menu interaktif) dengan perintah:

```bash
python src/main.py