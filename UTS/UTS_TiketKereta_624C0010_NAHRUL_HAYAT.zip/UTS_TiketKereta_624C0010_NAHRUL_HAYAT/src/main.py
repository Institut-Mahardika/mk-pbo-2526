from domain.tiket_ekonomi import TiketEkonomi
from domain.tiket_bisnis import TiketBisnis
from domain.pelanggan import Pelanggan
import os

daftar_tiket_terbeli = []
pemesanan_terakhir = {}

def input_validasi(prompt, tipe=str, allow_empty=False):
    while True:
        try:
            nilai = input(prompt).strip()
            if not allow_empty and not nilai:
                print("Input tidak boleh kosong.")
                continue

            if tipe == int:
                nilai = int(nilai)
                if nilai <= 0:
                    print("Nilai harus positif.")
                    continue
            return nilai
        except ValueError:
            print("Input tidak sesuai tipe data yang diharapkan.")

def pesan_tiket():
    lihat_daftar_tiket()
    print("\n=== [1] PESAN TIKET KERETA ===")

    nama_penumpang = input_validasi("Nama Penumpang: ")
    tujuan = input_validasi("Stasiun Tujuan: ")
    tanggal = input_validasi("Tanggal Keberangkatan (yyyy-mm-dd): ")
    jumlah_tiket = input_validasi("Jumlah Tiket: ", tipe=int)
    kontak_penumpang = input_validasi("Nomor Kontak: ")

    # Membuat objek Pelanggan
    pembeli = Pelanggan(nama_penumpang, kontak_penumpang)

    print("\nPilih Kelas:")
    print(" [1] Ekonomi (KA Serayu)")
    print(" [2] Bisnis (KA Argo Wilis)")
    kelas_pilihan = input_validasi("Pilih kelas (1/2): ", tipe=int)

    objek_tiket = None
    nama_ka = ""
    kursi_awal = "A1"

    if kelas_pilihan == 1:
        nama_ka = "KA Serayu"
        objek_tiket = TiketEkonomi(nama_ka, "Bandung", tujuan, tanggal, kursi_awal)
    elif kelas_pilihan == 2:
        nama_ka = "KA Argo Wilis"
        objek_tiket = TiketBisnis(nama_ka, "Bandung", tujuan, tanggal, kursi_awal)
    else:
        print("Kelas tidak valid. Pembelian dibatalkan.")
        return
    
    total_harga_per_tiket = objek_tiket.hitung_total()
    total_bayar = total_harga_per_tiket * jumlah_tiket

    for i in range(jumlah_tiket):
        kursi_unik = f"{objek_tiket.kode_kursi}{i+1}"
        try:
            if kelas_pilihan == 1:
                tiket_baru = TiketEkonomi(nama_ka, "Bandung", tujuan, tanggal, kursi_unik)
            else:
                tiket_baru = TiketBisnis(nama_ka, "Bandung", tujuan, tanggal, kursi_unik)

            daftar_tiket_terbeli.append(tiket_baru)
        except ValueError as e:
            print(f"Error saat set kursi: {e}")
            return
    
    global pemesanan_terakhir
    pemesanan_terakhir = {
        'nama': nama_penumpang,
        'tujuan': tujuan,
        'jumlah': jumlah_tiket,
        'total_bayar' : total_bayar,
        'kelas' : objek_tiket.NAMA_KELAS,
    }

    print("\n✅ PEMESANAN BERHASIL!")
    print(f"  > Penumpang: {nama_penumpang}")
    print(f"  > Tujuan: {tujuan}")
    print(f"  > Kelas: {objek_tiket.NAMA_KELAS}")
    print(f"  > Total Pembayaran ({jumlah_tiket} tiket): Rp {total_bayar:,.0f}")
    print(f"\n\n Terima Kasih telah membeli tiket, {nama_penumpang}!")

def lihat_daftar_tiket():
    print("\n--- [2] DAFTAR TIKET TERSEDIA ---")
    
    # Contoh Polimorfisme: List berisi objek dari berbagai subclass
    daftar_demo = [
        TiketEkonomi("KA Progo", "JOG", "JKT", "2025-10-25", "E1A"),
        TiketBisnis("KA Taksaka", "JKT", "JOG", "2025-10-26", "B2C")
    ]
    
    for tiket in daftar_demo:
        # Panggilan deskripsi() akan memanggil method yang benar dari subclass (Polimorfisme)
        print("------------------------------------------")
        print(tiket.deskripsi())
        print(f"Harga Dasar (Enkapsulasi): {tiket.harga_dasar}") # Akses via getter

def lihat_ringkasan():
    print("\n--- [3] RINGKASAN PEMBELIAN TERAKHIR ---")
    if not pemesanan_terakhir:
        print("Belum ada pemesanan yang tercatat.")
        return

    print(f"Nama Pembeli: {pemesanan_terakhir['nama']}")
    print(f"Kelas Dibeli: {pemesanan_terakhir['kelas']}")
    print(f"Jumlah Tiket: {pemesanan_terakhir['jumlah']}")
    print(f"TOTAL BAYAR: Rp {pemesanan_terakhir['total_bayar']:,.0f}")
    
    print("\n--- Detail Tiket ---")
    count = 0
    for tiket in daftar_tiket_terbeli:
        if tiket.NAMA_KELAS == pemesanan_terakhir['kelas']:
            print(f"  - Tiket {count+1}: {tiket.nama_ka} | Kursi: {tiket.kode_kursi} | Harga: Rp {tiket.hitung_total():,.0f}")
            count += 1
            if count == pemesanan_terakhir['jumlah']:
                break
    

def main_menu():
    while True:
        print("\n===================================")
        print("=== SISTEM TIKET KERETA API OOP ===")
        print("===================================")
        print("[1] Pesan Tiket")
        print("[2] Daftar Tiket Tersedia")
        print("[3] Lihat Ringkasan Pembelian")
        print("[4] Keluar")
        
        pilihan = input("Pilih menu (1-4): ").strip()
        
        if pilihan == '1':
            os.system('cls')
            pesan_tiket()
        elif pilihan == '2':
            os.system('cls')
            lihat_daftar_tiket()
        elif pilihan == '3':
            os.system('cls')
            lihat_ringkasan()
        elif pilihan == '4':
            print("\nTerima kasih, program dihentikan.")
            break
        else:
            print("Pilihan tidak valid, silakan coba lagi.")

if __name__ == "__main__":
    main_menu()

