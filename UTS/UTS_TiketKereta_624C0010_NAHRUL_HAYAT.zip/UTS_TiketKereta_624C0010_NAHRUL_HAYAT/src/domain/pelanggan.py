# src/domain/pelanggan.py

class Pelanggan:
    """Kelas untuk merepresentasikan entitas Pelanggan/Penumpang."""
    
    def __init__(self, nama, kontak):
        # Atribut privat
        self.__nama = nama
        self.__kontak = kontak
        # Properti tambahan (opsional)
        self.riwayat_pembelian = []

    # --- Getter & Setter (Enkapsulasi) ---
    
    @property
    def nama(self):
        """Getter untuk __nama"""
        return self.__nama

    @nama.setter
    def nama(self, nilai):
        """Setter dengan validasi (Nama tidak boleh kosong)"""
        if not nilai.strip():
            raise ValueError("Nama pelanggan tidak boleh kosong.")
        self.__nama = nilai
        
    @property
    def kontak(self):
        """Getter untuk __kontak"""
        return self.__kontak

    @kontak.setter
    def kontak(self, nilai):
        """Setter dengan validasi (Kontak harus berupa string)"""
        if not isinstance(nilai, str) or not nilai.strip():
            raise ValueError("Kontak harus diisi.")
        self.__kontak = nilai

    # --- Metode Tambahan (Opsional) ---
    def tambah_pembelian(self, tiket_objek):
        """Menambahkan objek tiket yang sudah dibeli ke riwayat."""
        self.riwayat_pembelian.append(tiket_objek)

    def tampilkan_detail(self):
        """Menampilkan detail pelanggan."""
        return f"Pelanggan: {self.nama}, Kontak: {self.kontak}"