from domain.tiket_kereta import TiketKereta

class TiketEkonomi(TiketKereta):
    BIAYA_LAYANAN = 0
    NAMA_KELAS = "EKONOMI"

    def __init__(self, nama_ka, asal, tujuan, tanggal, kode_kursi):
        super().__init__(nama_ka, asal, tujuan, tanggal, 120000, kode_kursi)

    def hitung_total(self):
        return self.harga_dasar + self.BIAYA_LAYANAN
    
    def deskripsi(self):
        return(
            f"[{self.NAMA_KELAS}] {self.nama_ka} ({self.asal} ke {self.tujuan})"
            f" > Harga/tiket: Rp {self.hitung_total():,.0f} | Kursi: {self.kode_kursi}"
        )