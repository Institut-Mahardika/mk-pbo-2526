from domain.tiket_kereta import TiketKereta

class TiketBisnis(TiketKereta):
    BIAYA_LAYANAN = 50000
    NAMA_KELAS = "BISNIS"

    def __init__(self, nama_ka, asal, tujuan, tanggal, kode_kursi):
        super().__init__(nama_ka, asal, tujuan, tanggal, 300000, kode_kursi)
    
    def hitung_total(self):
        return self.harga_dasar + self.BIAYA_LAYANAN
    
    def deskripsi(self):
        return(
            f"[{self.NAMA_KELAS}] {self.nama_ka} ({self.asal} ke {self.tujuan}\n)"
            f" > Harga/tiket: Rp {self.hitung_total():,.0f} | Fasilitas: Snack + Bantal | Kursi: {self.kode_kursi}"
        )