from abc import ABC, abstractmethod

class TiketKereta(ABC):
    def __init__(self, nama_ka, asal, tujuan, tanggal, harga_dasar, kode_kursi):
        # atribut umum
        self.nama_ka = nama_ka
        self.asal = asal
        self.tujuan = tujuan
        self.tanggal = tanggal

        # enkapsulasi
        self.__harga_dasar = harga_dasar
        self.__kode_kursi = kode_kursi
    
    @property
    def harga_dasar(self):
        return self.__harga_dasar
    @harga_dasar.setter
    def harga_dasar(self, nilai):
        """Setter dengan validasi (Harga tidak boleh negatif)"""
        if nilai < 0:
            raise ValueError("Harga dasar tidak boleh negatif.")
        self.__harga_dasar = nilai

    @property
    def kode_kursi(self):
        """Getter untuk __kode_kursi"""
        return self.__kode_kursi

    @kode_kursi.setter
    def kode_kursi(self, nilai):
        """Setter dengan validasi (Kursi tidak boleh kosong/pendek)"""
        if not nilai or len(nilai) < 3:
            raise ValueError("Kode kursi tidak valid.")
        self.__kode_kursi = nilai

    # --- Method Abstrak (Abstraksi) ---
    
    @abstractmethod
    def hitung_total(self):
        """Wajib diimplementasikan: Menghitung total harga per tiket."""
        pass

    @abstractmethod
    def deskripsi(self):
        """Wajib diimplementasikan: Memberikan deskripsi tiket lengkap."""
        pass