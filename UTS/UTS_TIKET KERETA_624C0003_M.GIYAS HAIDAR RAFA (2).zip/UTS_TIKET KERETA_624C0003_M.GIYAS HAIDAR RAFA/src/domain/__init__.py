from domain.tiket_ekonomi import TiketEkonomi
from domain.tiket_bisnis import TiketBisnis


pembelian = []

def pesan_tiket():
    print("\n=== SISTEM PEMESANAN TIKET KERETA API ===")
    nama = input("Nama Penumpang : ").strip()
    tujuan = input("Tujuan         : ").strip()
    tanggal = input("Tanggal        : ").strip()

    try:
        usia = int(input("Usia Penumpang : "))
    except ValueError:
        print("❌ Usia harus berupa angka.")
        return

    pelajar = input("Apakah pelajar? (y/n): ").strip().lower() == "y"
    pulang_pergi = input("Apakah pulang-pergi? (y/n): ").strip().lower() == "y"

    print("\nKelas Kereta:")
    print("[1] Ekonomi")
    print("[2] Bisnis")
    pilihan = input("Pilih kelas (1/2): ").strip()

    try:
        jumlah = int(input("Jumlah Tiket   : "))
    except ValueError:
        print("❌ Jumlah tiket harus berupa angka.")
        return

    if pilihan == "1":
        tiket = TiketEkonomi(nama, tujuan, tanggal, jumlah, usia, pelajar, pulang_pergi)
    elif pilihan == "2":
        tiket = TiketBisnis(nama, tujuan, tanggal, jumlah, usia, pelajar, pulang_pergi)
    else:
        print("❌ Pilihan kelas tidak valid.")
        return

    pembelian.append(tiket)
    print(f"\n✅ Total Harga: Rp{tiket.hitung_total():,.0f}")
    print("Tiket berhasil dipesan!\n")

def ringkasan_pembelian():
    print("\n=== RINGKASAN PEMBELIAN ===")
    if not pembelian:
        print("Belum ada tiket yang dipesan.")
        return
    total = 0
    for t in pembelian:
        print(t.deskripsi())
        total += t.hitung_total()
    print(f"\nTOTAL SEMUA PEMBELIAN: Rp{total:,.0f}\n")

def contoh_polimorfisme():
    print("\n=== CONTOH POLIMORFISME ===")
    daftar = [
        TiketEkonomi("Ani", "Jakarta", "20-11-2025", 1, 10),
        TiketBisnis("Budi", "Bandung", "22-11-2025", 1, 19, True, True),
        
    ]
    for tiket in daftar:
        print(tiket.deskripsi())

def menu():
    while True:
        print("=== MENU UTAMA ===")
        print("[1] Pesan Tiket")
        print("[2] Lihat Ringkasan Pembelian")
        print("[3] Lihat Contoh Polimorfisme")
        print("[4] Keluar")
        pilih = input("Pilih menu: ").strip()

        if pilih == "1":
            pesan_tiket()
        elif pilih == "2":
            ringkasan_pembelian()
        elif pilih == "3":
            contoh_polimorfisme()
        elif pilih == "4":
            print("Terima kasih telah menggunakan sistem ini! 👋")
            break
        else:
            print("❌ Pilihan tidak valid.\n")

if __name__ == "__main__":
    menu()
