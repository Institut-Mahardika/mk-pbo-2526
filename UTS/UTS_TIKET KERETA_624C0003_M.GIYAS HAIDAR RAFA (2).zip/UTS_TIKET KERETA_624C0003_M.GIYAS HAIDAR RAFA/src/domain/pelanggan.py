class Pelanggan:
    def __init__(self, nama, usia, status):
        self.nama = nama
        self.usia = usia
        self.status = status  # "pelajar", "dewasa", "lansia"

    def hitung_diskon(self):
        if self.status.lower() == "pelajar":
            return 0.15
        elif self.usia >= 60:
            return 0.20
        return 0
