from .tiket_kereta import TiketKereta

class TiketEkonomi(TiketKereta):
    def __init__(self, nama_penumpang, tujuan, tanggal, jumlah_tiket, usia, pelajar=False, pulang_pergi=False):
        super().__init__(nama_penumpang, tujuan, tanggal, jumlah_tiket)
        self.__harga_dasar = 50000
        self.usia = usia
        self.pelajar = pelajar
        self.pulang_pergi = pulang_pergi

    def hitung_total(self):
        total = self.__harga_dasar * self.jumlah_tiket
        # Diskon usia/pelajar
        if self.usia < 12:
            total *= 0.5  # diskon anak-anak 50%
        elif self.pelajar:
            total *= 0.85  # diskon pelajar 15%
        # Tiket pulang-pergi
        if self.pulang_pergi:
            total *= 2
            total *= 0.9  # diskon 10% PP
        return total

    def deskripsi(self):
        jenis = "Pulang-Pergi" if self.pulang_pergi else "Sekali Jalan"
        return f"[EKONOMI] {self.nama_penumpang} - {self.tujuan} ({jenis}) {self.jumlah_tiket} tiket, Total: Rp{self.hitung_total():,.0f}"
