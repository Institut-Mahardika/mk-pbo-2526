from abc import ABC, abstractmethod

class TiketKereta(ABC):
    def __init__(self, nama_penumpang, tujuan, tanggal, jumlah_tiket):
        self.nama_penumpang = nama_penumpang
        self.tujuan = tujuan
        self.tanggal = tanggal
        self.jumlah_tiket = jumlah_tiket

    @abstractmethod
    def hitung_total(self):
        pass

    @abstractmethod
    def deskripsi(self):
        pass