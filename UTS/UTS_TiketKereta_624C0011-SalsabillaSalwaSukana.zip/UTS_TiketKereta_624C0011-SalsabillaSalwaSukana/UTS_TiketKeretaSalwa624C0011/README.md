# UTS Tiket Kereta Api

**Nama:** Salwaaa
**NPM:** 624c0011

## Deskripsi Singkat
Program ini mensimulasikan sistem pembelian tiket kereta api dengan konsep OOP Python:
- Abstraksi: Class `TiketKereta` sebagai class dasar abstrak.
- Pewarisan: Subclass `TiketEkonomi`, `TiketBisnis`, dan `TiketEksekutif`.
- Enkapsulasi: Atribut `__harga_dasar` dan `__kursi` menggunakan getter/setter.
- Polimorfisme: Method `deskripsi()` dan `hitung_total()` dioverride pada setiap subclass.

## Struktur Folder UTS_TiketKeretaSalwa624C0011
/ │ ├── src/ 
│   ├── domain/
│   │   ├── init.py                # Penanda folder Python package │   │   
├── tiket_kereta.py            # Class induk (TiketKereta) │   │   
├── tiket_ekonomi.py           # Subclass untuk tiket ekonomi │   │  
├── tiket_bisnis.py            # Subclass untuk tiket bisnis │   │  
├── tiket_eksekutif.py         # Subclass untuk tiket eksekutif │   │
│   └── main.py                        # File utama untuk menjalankan program │
├── requirements.txt                   # Daftar dependensi
├── launch.json                        # Konfigurasi VSCode 
└── README.md                          # Dokumentasi proyek ini

### Penjelasan Penerapan 4 Pilar OOP
1. *Encapsulation:*  
   Setiap atribut tiket (nama kereta, harga, fasilitas) disimpan di dalam class dan diakses melalui method tertentu.

2. *Inheritance:*  
   Class TiketKereta menjadi class induk, dan TiketEkonomi, TiketBisnis, serta TiketEksekutif merupakan subclass yang mewarisi atribut & method dari induknya.

3. *Polymorphism:*  
   Method tampilkan_info() ditulis ulang (override) pada setiap subclass untuk menampilkan informasi sesuai jenis tiket.

4. *Abstraction:*  
   Pengguna hanya berinteraksi melalui file main.py, tanpa perlu mengetahui detail implementasi class di folder domain.


### Contoh Input & Output Singkat
*Input (via main.py):*

=== SISTEM TIKET KERETA API ===
[1] Pesan Tiket
[2] Lihat Daftar Tiket
[3] Lihat Ringkasan Pembelian
[4] Keluar
Pilih menu:
Pilih menu: 2

=== DAFTAR KELAS TIKET ===
[EKONOMI] Tujuan Surabaya - Rp 120000/orang
[BISNIS] Tujuan Yogyakarta - Rp 400000/orang + Snack & AC
[EKSEKUTIF] Tujuan Jakarta - Rp 700000/orang + Makanan, Reclining Seat, WiFi

=== SISTEM TIKET KERETA API ===
[1] Pesan Tiket
[2] Lihat Daftar Tiket
[3] Lihat Ringkasan Pembelian
[4] Keluar
Pilih menu:
Pilih menu: 1

=== PESAN TIKET ===
Nama Penumpang : Salwa  
Tujuan         : Bandung
Tanggal        : 26 oktober 2025
Jumlah Tiket   : 2
Kelas Kereta (ekonomi/bisnis/eksekutif): bisnis

Total Harga    : Rp 800,000
Terima kasih telah membeli tiket, Salwa!

=== SISTEM TIKET KERETA API ===
[1] Pesan Tiket
[2] Lihat Daftar Tiket
[3] Lihat Ringkasan Pembelian
[4] Keluar
Pilih menu: 3

=== RINGKASAN PEMBELIAN ===
[BISNIS] Tujuan Bandung - Rp 400000/orang + Snack & AC | Total: Rp 800,000

Total Biaya Semua Tiket: Rp 800,000


### Cara Menjalankan Program
1. Pastikan Python sudah terinstal di komputer.  
2. Buka folder proyek di terminal atau VS Code.  
3. Jalankan perintah berikut:
   ```bash
   python src/main.py
