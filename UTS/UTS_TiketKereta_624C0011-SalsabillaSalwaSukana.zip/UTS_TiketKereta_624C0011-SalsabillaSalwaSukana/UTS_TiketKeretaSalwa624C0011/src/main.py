from domain.tiket_ekonomi import TiketEkonomi
from domain.tiket_bisnis import TiketBisnis
from domain.tiket_eksekutif import TiketEksekutif

daftar_tiket = []
pembelian = []

def pesan_tiket():
    print("\n=== PESAN TIKET ===")
    nama = input("Nama Penumpang : ")
    tujuan = input("Tujuan         : ")
    tanggal = input("Tanggal        : ")
    jumlah = int(input("Jumlah Tiket   : "))
    kelas = input("Kelas Kereta (ekonomi/bisnis/eksekutif): ").lower()

    if kelas == "ekonomi":
        tiket = TiketEkonomi(nama, tujuan, tanggal, jumlah)
    elif kelas == "bisnis":
        tiket = TiketBisnis(nama, tujuan, tanggal, jumlah)
    elif kelas == "eksekutif":
        tiket = TiketEksekutif(nama, tujuan, tanggal, jumlah)
    else:
        print("Kelas tidak valid.")
        return

    total = tiket.hitung_total()
    print(f"\nTotal Harga    : Rp {total:,}")
    print(f"Terima kasih telah membeli tiket, {nama}!\n")

    pembelian.append(tiket)

def lihat_daftar_tiket():
    print("\n=== DAFTAR KELAS TIKET ===")
    daftar = [TiketEkonomi("Demo","Surabaya","01-11-2025",1),
              TiketBisnis("Demo","Yogyakarta","01-11-2025",1),
              TiketEksekutif("Demo","Jakarta","01-11-2025",1)]
    for tiket in daftar:
        print(tiket.deskripsi())

def ringkasan_pembelian():
    print("\n=== RINGKASAN PEMBELIAN ===")
    if not pembelian:
        print("Belum ada tiket dibeli.")
        return
    total_semua = 0
    for tiket in pembelian:
        print(tiket.deskripsi(), f"| Total: Rp {tiket.hitung_total():,}")
        total_semua += tiket.hitung_total()
    print(f"\nTotal Biaya Semua Tiket: Rp {total_semua:,}")

def menu():
    while True:
        print("\n=== SISTEM TIKET KERETA API ===")
        print("[1] Pesan Tiket")
        print("[2] Lihat Daftar Tiket")
        print("[3] Lihat Ringkasan Pembelian")
        print("[4] Keluar")
        pilihan = input("Pilih menu: ")

        if pilihan == "1":
            pesan_tiket()
        elif pilihan == "2":
            lihat_daftar_tiket()
        elif pilihan == "3":
            ringkasan_pembelian()
        elif pilihan == "4":
            print("Terima kasih telah menggunakan sistem ini!")
            break
        else:
            print("Pilihan tidak valid.")

if __name__ == "__main__":
    menu()