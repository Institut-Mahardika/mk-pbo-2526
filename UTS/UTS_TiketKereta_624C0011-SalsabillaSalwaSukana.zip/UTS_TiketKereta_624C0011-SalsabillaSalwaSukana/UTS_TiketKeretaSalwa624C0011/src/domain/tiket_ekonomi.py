from .tiket_kereta import TiketKereta

class TiketEkonomi(TiketKereta):
    def __init__(self, nama, tujuan, tanggal, jumlah):
        super().__init__(nama, tujuan, tanggal, jumlah)
        self.harga_dasar = 120000
        self.kursi = "EKO-" + str(hash(nama) % 100)

    def hitung_total(self):
        return self.harga_dasar * self.jumlah

    def deskripsi(self):
        return f"[EKONOMI] Tujuan {self.tujuan} - Rp {self.harga_dasar}/orang"