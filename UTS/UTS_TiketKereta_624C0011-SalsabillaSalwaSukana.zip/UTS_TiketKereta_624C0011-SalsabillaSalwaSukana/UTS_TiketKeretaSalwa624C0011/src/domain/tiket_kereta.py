from abc import ABC, abstractmethod

class TiketKereta(ABC):
    def __init__(self, nama, tujuan, tanggal, jumlah):
        self.nama = nama
        self.tujuan = tujuan
        self.tanggal = tanggal
        self.jumlah = jumlah
        self.__harga_dasar = 0
        self.__kursi = None

    # Getter & Setter (Enkapsulasi)
    @property
    def harga_dasar(self):
        return self.__harga_dasar

    @harga_dasar.setter
    def harga_dasar(self, value):
        if value < 0:
            raise ValueError("Harga tidak boleh negatif.")
        self.__harga_dasar = value

    @property
    def kursi(self):
        return self.__kursi

    @kursi.setter
    def kursi(self, value):
        if not value:
            raise ValueError("Nomor kursi tidak boleh kosong.")
        self.__kursi = value

    @abstractmethod
    def hitung_total(self):
        pass

    @abstractmethod
    def deskripsi(self):
        pass
