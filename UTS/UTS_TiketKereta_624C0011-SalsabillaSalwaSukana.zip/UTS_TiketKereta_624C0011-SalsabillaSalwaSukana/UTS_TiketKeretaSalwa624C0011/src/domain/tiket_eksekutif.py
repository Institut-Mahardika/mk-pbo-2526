from .tiket_kereta import TiketKereta

class TiketEksekutif(TiketKereta):
    def __init__(self, nama, tujuan, tanggal, jumlah):
        super().__init__(nama, tujuan, tanggal, jumlah)
        self.harga_dasar = 700000
        self.kursi = "EKS-" + str(hash(nama) % 100)
        self.fasilitas = "Makanan, Reclining Seat, WiFi"

    def hitung_total(self):
        return self.harga_dasar * self.jumlah

    def deskripsi(self):
        return f"[EKSEKUTIF] Tujuan {self.tujuan} - Rp {self.harga_dasar}/orang + {self.fasilitas}"