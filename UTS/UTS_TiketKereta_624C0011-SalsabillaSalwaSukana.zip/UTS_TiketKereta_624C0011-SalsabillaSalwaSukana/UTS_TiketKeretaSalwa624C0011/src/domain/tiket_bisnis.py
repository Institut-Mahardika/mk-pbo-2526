from .tiket_kereta import TiketKereta

class TiketBisnis(TiketKereta):
    def __init__(self, nama, tujuan, tanggal, jumlah):
        super().__init__(nama, tujuan, tanggal, jumlah)
        self.harga_dasar = 400000
        self.kursi = "BIS-" + str(hash(nama) % 100)
        self.fasilitas = "Snack & AC"

    def hitung_total(self):
        return self.harga_dasar * self.jumlah

    def deskripsi(self):
        return f"[BISNIS] Tujuan {self.tujuan} - Rp {self.harga_dasar}/orang + {self.fasilitas}"